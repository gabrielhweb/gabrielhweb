import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { APP_TITLE } from "@/const";
import { useState } from "react";

export default function Home() {
  const [alturaTotalInput, setAlturaTotalInput] = useState("");
  const [numeroDegrausInput, setNumeroDegrausInput] = useState("");
  const [profundidadePisoInput, setProfundidadePisoInput] = useState("");
  
  const [alturaEspelho, setAlturaEspelho] = useState<number | null>(null);
  const [comprimentoTotal, setComprimentoTotal] = useState<number | null>(null);
  const [mostrarResultados, setMostrarResultados] = useState(false);
  const [sugestaoNumero, setSugestaoNumero] = useState<number | null>(null);
  const [sugestaoProfundidade, setSugestaoProfundidade] = useState<number | null>(null);

  const calcularNumeroIdeal = () => {
    const alturaTotal = parseFloat(alturaTotalInput);

    if (isNaN(alturaTotal) || alturaTotal <= 0) {
      alert("Por favor, preencha a altura total com um valor válido.");
      return;
    }

    // Altura ideal de degrau: entre 16 e 23 cm
    // Vamos usar 19 cm como referência (meio termo)
    const alturaIdeal = 19;
    
    // Calcula o número ideal de espelhos
    const numeroEspelhos = Math.round(alturaTotal / alturaIdeal);
    
    // O número de pisos é sempre um a menos que o número de espelhos
    const numeroPisos = numeroEspelhos - 1;
    
    // Calcula a altura real que cada espelho terá
    const alturaReal = alturaTotal / numeroEspelhos;
    
    setSugestaoNumero(numeroPisos);
    setNumeroDegrausInput(numeroPisos.toString());
    
    // Mostra uma mensagem informativa
    alert(
      `Sugestão calculada!\n\n` +
      `Para uma altura total de ${alturaTotal} cm:\n` +
      `• Número ideal de pisos (degraus): ${numeroPisos}\n` +
      `• Número de espelhos: ${numeroEspelhos}\n` +
      `• Altura de cada espelho: ${alturaReal.toFixed(2)} cm\n\n` +
      `Essa altura está dentro da faixa confortável (16-23 cm).`
    );
  };

  const calcularAlturaEspelho = () => {
    const alturaTotal = parseFloat(alturaTotalInput);
    const numeroPisos = parseInt(numeroDegrausInput);

    if (isNaN(alturaTotal) || isNaN(numeroPisos)) {
      alert("Por favor, preencha a altura total e o número de degraus (pisos).");
      return;
    }

    if (alturaTotal <= 0 || numeroPisos <= 0) {
      alert("Todos os valores devem ser maiores que zero.");
      return;
    }

    // CORREÇÃO 2: O número de espelhos é sempre n + 1
    const numeroEspelhos = numeroPisos + 1;
    
    // Calcula a altura de cada espelho
    const alturaEspelhoCalculada = alturaTotal / numeroEspelhos;

    // Mostra uma mensagem informativa
    alert(
      `Altura do espelho calculada!\n\n` +
      `Com ${numeroPisos} pisos (degraus) e altura de ${alturaTotal} cm:\n` +
      `• Número de espelhos: ${numeroEspelhos}\n` +
      `• Altura de cada espelho: ${alturaEspelhoCalculada.toFixed(2)} cm\n\n` +
      (alturaEspelhoCalculada >= 16 && alturaEspelhoCalculada <= 23
        ? "✓ Altura confortável (16-23 cm)!"
        : "⚠ Atenção: A altura ideal está entre 16-23 cm.")
    );
  };

  const calcularProfundidadeIdeal = () => {
    const alturaTotal = parseFloat(alturaTotalInput);
    const numeroPisos = parseInt(numeroDegrausInput);

    if (isNaN(alturaTotal) || isNaN(numeroPisos)) {
      alert("Por favor, preencha a altura total e o número de degraus (pisos).");
      return;
    }

    if (alturaTotal <= 0 || numeroPisos <= 0) {
      alert("Todos os valores devem ser maiores que zero.");
      return;
    }

    // O número de espelhos é sempre n + 1
    const numeroEspelhos = numeroPisos + 1;
    const alturaEspelho = alturaTotal / numeroEspelhos;

    // Fórmula de Blondel: 2 × altura + profundidade = 63-65 cm
    // Vamos usar 64 cm como valor ideal (meio termo)
    // Portanto: profundidade = 64 - (2 × altura)
    const profundidadeIdeal = 64 - (2 * alturaEspelho);

    // Verifica se a profundidade está em uma faixa aceitável (mínimo 25 cm, máximo 32 cm)
    if (profundidadeIdeal < 25) {
      alert(
        `Atenção!\n\n` +
        `Com ${numeroPisos} pisos:\n` +
        `• Altura de cada espelho: ${alturaEspelho.toFixed(2)} cm\n` +
        `• Profundidade ideal calculada: ${profundidadeIdeal.toFixed(2)} cm\n\n` +
        `⚠️ A profundidade ficou muito pequena (< 25 cm).\n` +
        `Recomenda-se usar MENOS pisos para aumentar a profundidade.`
      );
      return;
    }

    if (profundidadeIdeal > 32) {
      alert(
        `Atenção!\n\n` +
        `Com ${numeroPisos} pisos:\n` +
        `• Altura de cada espelho: ${alturaEspelho.toFixed(2)} cm\n` +
        `• Profundidade ideal calculada: ${profundidadeIdeal.toFixed(2)} cm\n\n` +
        `⚠️ A profundidade ficou muito grande (> 32 cm).\n` +
        `Recomenda-se usar MAIS pisos para reduzir a profundidade.`
      );
      return;
    }

    setSugestaoProfundidade(profundidadeIdeal);
    setProfundidadePisoInput(profundidadeIdeal.toFixed(2));

    // Mostra uma mensagem informativa
    alert(
      `Profundidade ideal calculada!\n\n` +
      `Com ${numeroPisos} pisos e altura de ${alturaTotal} cm:\n` +
      `• Altura de cada espelho: ${alturaEspelho.toFixed(2)} cm\n` +
      `• Profundidade ideal: ${profundidadeIdeal.toFixed(2)} cm\n\n` +
      `Fórmula de Blondel: 2 × ${alturaEspelho.toFixed(2)} + ${profundidadeIdeal.toFixed(2)} = ${(2 * alturaEspelho + profundidadeIdeal).toFixed(2)} cm ✓`
    );
  };

  const calcular = () => {
    const alturaTotal = parseFloat(alturaTotalInput);
    const numeroPisos = parseInt(numeroDegrausInput);
    const profundidadePiso = parseFloat(profundidadePisoInput);

    if (isNaN(alturaTotal) || isNaN(numeroPisos) || isNaN(profundidadePiso)) {
      alert("Por favor, preencha todos os campos com valores válidos.");
      return;
    }

    if (alturaTotal <= 0 || numeroPisos <= 0 || profundidadePiso <= 0) {
      alert("Todos os valores devem ser maiores que zero.");
      return;
    }

    // CORREÇÃO 2: Cálculo A - Altura de cada espelho
    // O número de espelhos é sempre n + 1 (onde n é o número de pisos)
    const numeroEspelhos = numeroPisos + 1;
    const alturaCalculada = alturaTotal / numeroEspelhos;
    
    // CORREÇÃO 4: Validação de valores absurdos
    if (alturaCalculada < 10 || alturaCalculada > 25) {
      const avisoAltura = alturaCalculada < 10 
        ? `A altura do espelho (${alturaCalculada.toFixed(2)} cm) está muito baixa.\n\n` +
          `⚠️ Verifique se a Altura Total foi inserida corretamente em CENTÍMETROS.\n` +
          `Exemplo: para 3 metros, digite 300 (não 3).`
        : `A altura do espelho (${alturaCalculada.toFixed(2)} cm) está muito alta.\n\n` +
          `⚠️ Considere aumentar o número de degraus para uma escada mais confortável.`;
      
      const continuar = confirm(
        `${avisoAltura}\n\n` +
        `A faixa ideal é 16-23 cm.\n\n` +
        `Deseja continuar mesmo assim?`
      );
      
      if (!continuar) {
        return;
      }
    }
    
    // CORREÇÃO 3: Cálculo B - Comprimento total da escada no chão
    // Comprimento = n × (profundidade + 1cm de tolerância)
    const tolerancia = 1; // 1cm de tolerância por piso
    const comprimentoCalculado = numeroPisos * (profundidadePiso + tolerancia);

    setAlturaEspelho(alturaCalculada);
    setComprimentoTotal(comprimentoCalculado);
    setMostrarResultados(true);
  };

  const limpar = () => {
    setAlturaTotalInput("");
    setNumeroDegrausInput("");
    setProfundidadePisoInput("");
    setAlturaEspelho(null);
    setComprimentoTotal(null);
    setMostrarResultados(false);
    setSugestaoNumero(null);
    setSugestaoProfundidade(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex flex-col">
      {/* Header */}
      <header className="w-full py-6 px-4 bg-white/80 backdrop-blur-sm border-b border-blue-100 shadow-sm">
        <div className="container">
          <h1 className="text-3xl font-bold text-blue-900">{APP_TITLE}</h1>
          <p className="text-sm text-blue-600 mt-1">Calcule o espaço que sua escada ocupará</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-8 md:py-12">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Calculadora de Número Ideal */}
          <Card className="shadow-lg border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <span className="text-2xl">✨</span>
                Calcular Número Ideal de Degraus
              </CardTitle>
              <CardDescription className="text-purple-50">
                Não sabe quantos degraus usar? Deixe a calculadora sugerir!
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex gap-4 items-end">
                <div className="flex-1 space-y-2">
                  <Label htmlFor="alturaTotalNumero" className="text-base font-semibold text-purple-800">
                    Altura Total (cm)
                  </Label>
                  <Input
                    id="alturaTotalNumero"
                    type="number"
                    placeholder="Ex: 280"
                    value={alturaTotalInput}
                    onChange={(e) => setAlturaTotalInput(e.target.value)}
                    className="text-lg h-12 border-purple-300 focus:border-purple-500 focus:ring-purple-500"
                    min="0"
                    step="0.01"
                  />
                </div>
                <Button
                  onClick={calcularNumeroIdeal}
                  className="h-12 px-8 text-lg bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold shadow-md"
                >
                  Sugerir Número
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* CORREÇÃO 1: Título corrigido - Calcular Altura do Espelho */}
          <Card className="shadow-lg border-green-200 bg-gradient-to-r from-green-50 to-emerald-50">
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <span className="text-2xl">📐</span>
                Calcular Altura do Espelho
              </CardTitle>
              <CardDescription className="text-green-50">
                Informe quantos pisos (degraus) quer e descubra a altura de cada espelho!
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid gap-4 md:grid-cols-3 items-end">
                <div className="space-y-2">
                  <Label htmlFor="alturaTotalAltura" className="text-base font-semibold text-green-800">
                    Altura Total (cm)
                  </Label>
                  <Input
                    id="alturaTotalAltura"
                    type="number"
                    placeholder="Ex: 280"
                    value={alturaTotalInput}
                    onChange={(e) => setAlturaTotalInput(e.target.value)}
                    className="text-lg h-12 border-green-300 focus:border-green-500 focus:ring-green-500"
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="numeroDegrausAltura" className="text-base font-semibold text-green-800">
                    Número de Pisos
                  </Label>
                  <Input
                    id="numeroDegrausAltura"
                    type="number"
                    placeholder="Ex: 15"
                    value={numeroDegrausInput}
                    onChange={(e) => setNumeroDegrausInput(e.target.value)}
                    className="text-lg h-12 border-green-300 focus:border-green-500 focus:ring-green-500"
                    min="1"
                    step="1"
                  />
                </div>
                <Button
                  onClick={calcularAlturaEspelho}
                  className="h-12 px-8 text-lg bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-semibold shadow-md"
                >
                  Calcular Altura
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Calculadora de Profundidade Ideal */}
          <Card className="shadow-lg border-orange-200 bg-gradient-to-r from-orange-50 to-amber-50">
            <CardHeader className="bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <span className="text-2xl">📏</span>
                Calcular Profundidade Ideal do Piso
              </CardTitle>
              <CardDescription className="text-orange-50">
                Descubra a profundidade ideal usando a fórmula de Blondel!
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid gap-4 md:grid-cols-3 items-end">
                <div className="space-y-2">
                  <Label htmlFor="alturaTotalProf" className="text-base font-semibold text-orange-800">
                    Altura Total (cm)
                  </Label>
                  <Input
                    id="alturaTotalProf"
                    type="number"
                    placeholder="Ex: 280"
                    value={alturaTotalInput}
                    onChange={(e) => setAlturaTotalInput(e.target.value)}
                    className="text-lg h-12 border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="numeroDegrausProf" className="text-base font-semibold text-orange-800">
                    Número de Pisos
                  </Label>
                  <Input
                    id="numeroDegrausProf"
                    type="number"
                    placeholder="Ex: 15"
                    value={numeroDegrausInput}
                    onChange={(e) => setNumeroDegrausInput(e.target.value)}
                    className="text-lg h-12 border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                    min="1"
                    step="1"
                  />
                </div>
                <Button
                  onClick={calcularProfundidadeIdeal}
                  className="h-12 px-8 text-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white font-semibold shadow-md"
                >
                  Sugerir Profundidade
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* CORREÇÃO 5: Diagrama Explicativo */}
          <Card className="shadow-lg border-indigo-200 bg-gradient-to-r from-indigo-50 to-purple-50">
            <CardHeader className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <span className="text-2xl">💡</span>
                Entenda a Diferença: Pisos vs Espelhos
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg border-2 border-indigo-200">
                  <pre className="text-sm font-mono text-gray-700 overflow-x-auto">
{`
    ┌─────────────────┐ ← Laje (Piso Superior)
    │                 │
    └─────┐  Espelho 11
          ├─────────┐   ← Piso 10 (onde se pisa)
          │ Espelho │
          │    10   │
    ┌─────┴─────────┤   ← Piso 9
    │   Espelho 9   │
    ├───────────────┤   ← Piso 8
    │   Espelho 8   │
    ├───────────────┤   ← Piso 7
    │       ...     │
    ├───────────────┤   ← Piso 2
    │   Espelho 2   │
    ├───────────────┤   ← Piso 1 (primeiro degrau)
    │   Espelho 1   │
    └───────────────┘
    ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ← Chão (Piso Inferior)

    📊 Exemplo: 10 PISOS = 11 ESPELHOS
    
    • PISO: A parte horizontal onde você pisa (10 unidades)
    • ESPELHO: A parte vertical entre os pisos (11 unidades)
    • O último espelho é a subida final para a laje!
`}
                  </pre>
                </div>
                <div className="bg-indigo-100 p-4 rounded-lg border border-indigo-300">
                  <p className="text-sm text-indigo-900 font-semibold mb-2">
                    📝 Nota Importante:
                  </p>
                  <p className="text-sm text-indigo-800">
                    Quando você informa o <strong>"Número de Degraus"</strong>, está se referindo aos <strong>PISOS</strong> (onde se pisa). 
                    Nossa calculadora automaticamente considera que o número de <strong>ESPELHOS</strong> (alturas) é sempre <strong>um a mais</strong>, 
                    pois o último espelho é a subida final para o piso superior (laje).
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Formulário Principal */}
          <Card className="shadow-xl border-blue-100">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
              <CardTitle className="text-2xl">Calculadora de Escadas</CardTitle>
              <CardDescription className="text-blue-50">
                Preencha os campos abaixo para calcular as dimensões da sua escada
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 md:p-8">
              <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="alturaTotal" className="text-base font-semibold text-gray-700">
                      Altura Total (cm)
                    </Label>
                    <Input
                      id="alturaTotal"
                      type="number"
                      placeholder="Ex: 280"
                      value={alturaTotalInput}
                      onChange={(e) => setAlturaTotalInput(e.target.value)}
                      className="text-lg h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      min="0"
                      step="0.01"
                    />
                    <p className="text-xs text-gray-500">
                      Altura do chão inferior ao chão superior
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="numeroDegraus" className="text-base font-semibold text-gray-700">
                      Número de Degraus (Pisos)
                      {sugestaoNumero && (
                        <span className="ml-2 text-xs text-purple-600 font-normal">
                          (sugerido: {sugestaoNumero})
                        </span>
                      )}
                    </Label>
                    <Input
                      id="numeroDegraus"
                      type="number"
                      placeholder="Ex: 15"
                      value={numeroDegrausInput}
                      onChange={(e) => setNumeroDegrausInput(e.target.value)}
                      className="text-lg h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      min="1"
                      step="1"
                    />
                    <p className="text-xs text-gray-500">
                      Quantidade de pisos (onde se pisa)
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="profundidadePiso" className="text-base font-semibold text-gray-700">
                      Profundidade do Piso (cm)
                      {sugestaoProfundidade && (
                        <span className="ml-2 text-xs text-orange-600 font-normal">
                          (sugerido: {sugestaoProfundidade.toFixed(2)})
                        </span>
                      )}
                    </Label>
                    <Input
                      id="profundidadePiso"
                      type="number"
                      placeholder="Ex: 28"
                      value={profundidadePisoInput}
                      onChange={(e) => setProfundidadePisoInput(e.target.value)}
                      className="text-lg h-12 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      min="0"
                      step="0.01"
                    />
                    <p className="text-xs text-gray-500">
                      Parte horizontal onde se pisa (27-30 cm recomendado)
                    </p>
                  </div>
                </div>

                {/* Botões de Ação */}
                <div className="flex gap-4 pt-4">
                  <Button
                    onClick={calcular}
                    className="flex-1 h-12 text-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md"
                  >
                    Calcular Dimensões
                  </Button>
                  <Button
                    onClick={limpar}
                    variant="outline"
                    className="h-12 px-8 text-lg border-gray-300 hover:bg-gray-50"
                  >
                    Limpar
                  </Button>
                </div>
              </div>

              {/* Resultados */}
              {mostrarResultados && alturaEspelho !== null && comprimentoTotal !== null && (
                <div className="mt-8 pt-8 border-t border-gray-200">
                  <h3 className="text-xl font-bold text-gray-800 mb-6">Resultados:</h3>
                  <div className="grid gap-6 md:grid-cols-2">
                    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-md">
                      <CardHeader>
                        <CardTitle className="text-green-800 text-lg">
                          Altura de cada espelho
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-4xl font-bold text-green-700">
                          {alturaEspelho.toFixed(2)} cm
                        </p>
                        <p className="text-sm text-green-600 mt-2">
                          Altura vertical de cada espelho
                        </p>
                        <p className="text-xs text-green-700 mt-2">
                          {parseInt(numeroDegrausInput)} pisos = {parseInt(numeroDegrausInput) + 1} espelhos
                        </p>
                        {alturaEspelho >= 16 && alturaEspelho <= 23 && (
                          <p className="text-xs text-green-700 mt-2 font-semibold">
                            ✓ Altura confortável!
                          </p>
                        )}
                        {(alturaEspelho < 16 || alturaEspelho > 23) && (
                          <p className="text-xs text-orange-700 mt-2 font-semibold">
                            ⚠ Fora da faixa ideal (16-23 cm)
                          </p>
                        )}
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 shadow-md">
                      <CardHeader>
                        <CardTitle className="text-blue-800 text-lg">
                          Comprimento total no chão
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-4xl font-bold text-blue-700">
                          {comprimentoTotal.toFixed(2)} cm
                        </p>
                        <p className="text-sm text-blue-600 mt-2">
                          = {(comprimentoTotal / 100).toFixed(2)} metros
                        </p>
                        <p className="text-xs text-blue-700 mt-2">
                          Inclui 1cm de tolerância por piso
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Informações Adicionais */}
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">📐 Informações Importantes:</h4>
                    <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                      <li>
                        A altura ideal de cada espelho deve estar entre <strong>16 e 23 cm</strong> para conforto.
                      </li>
                      <li>
                        A profundidade do piso recomendada é entre <strong>27 e 30 cm</strong>.
                      </li>
                      <li>
                        A fórmula de Blondel sugere: <strong>2 × altura + profundidade = 63-65 cm</strong>.
                      </li>
                      <li>
                        Sua escada: 2 × {alturaEspelho.toFixed(2)} + {profundidadePisoInput} = {(2 * alturaEspelho + parseFloat(profundidadePisoInput)).toFixed(2)} cm
                        {(2 * alturaEspelho + parseFloat(profundidadePisoInput)) >= 63 && 
                         (2 * alturaEspelho + parseFloat(profundidadePisoInput)) <= 65 && (
                          <strong className="text-green-700"> ✓ Ideal!</strong>
                        )}
                      </li>
                      <li>
                        O comprimento inclui <strong>1cm de tolerância</strong> adicional em cada piso.
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Explicação */}
          <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
            <h3 className="text-lg font-bold text-gray-800 mb-3">Como funciona o cálculo?</h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong className="text-purple-700">Número ideal de degraus (pisos):</strong> A calculadora sugere automaticamente quantos pisos usar para que cada espelho tenha aproximadamente 19 cm de altura (valor médio da faixa confortável de 16-23 cm). Lembre-se: o número de espelhos é sempre um a mais que o número de pisos!
              </p>
              <p>
                <strong className="text-green-700">Altura do espelho:</strong> É calculada dividindo a altura total pelo número de espelhos (que é o número de pisos + 1). 
                Por exemplo, se você tem 280 cm de altura e quer 10 pisos: 280 ÷ (10 + 1) = 280 ÷ 11 = 25,45 cm por espelho.
              </p>
              <p>
                <strong className="text-orange-700">Profundidade ideal do piso:</strong> Com base na altura total e no número de pisos escolhido, a calculadora usa a fórmula de Blondel (2 × altura + profundidade = 64 cm) para sugerir a profundidade ideal que tornará a escada mais confortável.
              </p>
              <p>
                <strong className="text-blue-700">Comprimento total no chão:</strong> É calculado multiplicando o número de pisos pela profundidade de cada piso, mais 1cm de tolerância por piso.
                Por exemplo: 10 pisos × (20cm + 1cm) = 10 × 21 = 210 cm.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full py-6 px-4 bg-white border-t border-gray-200 mt-8">
        <div className="container text-center text-sm text-gray-600">
          <p>Calculadora de Escadas - Ferramenta para planejamento de construção</p>
        </div>
      </footer>
    </div>
  );
}

